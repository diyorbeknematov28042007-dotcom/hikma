# HIKMA Landing Page

Production-ready, mobile-first landing page for **HIKMA** built with Next.js, TypeScript and Tailwind CSS.

## Stack

- Next.js 16.3.x (App Router)
- React 19.2.x
- TypeScript
- Tailwind CSS 4.3.x
- Lucide React
- Vercel-ready deployment
- Uzbek / Russian / English routes: `/uz`, `/ru`, `/en`

## Local development

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`. The root path redirects to `/uz`.

## Environment variables

Copy `.env.example` to `.env.local`.

```env
NEXT_PUBLIC_SITE_URL=https://your-domain.example
NEXT_PUBLIC_TELEGRAM_URL=https://t.me/your_username
NEXT_PUBLIC_INSTAGRAM_URL=https://instagram.com/your_username
NEXT_PUBLIC_CONTACT_EMAIL=hello@example.com

TELEGRAM_BOT_TOKEN=123456:ABC...
TELEGRAM_CHAT_ID=123456789
```

`TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` are used only on the server by `/api/contact`. Never prefix them with `NEXT_PUBLIC_`.

The form validates input on the client and again on the server. It includes a honeypot field and sends valid inquiries to the configured Telegram chat.

## GitHub repository structure

Upload the project **from this root**. Do not put the source inside another `hikma-landing/` folder.

```text
/
├── .github/
│   └── workflows/
│       └── ci.yml
├── public/
│   └── og.svg
├── src/
│   ├── app/
│   │   ├── [locale]/
│   │   │   ├── layout.tsx
│   │   │   ├── opengraph-image.tsx
│   │   │   ├── twitter-image.tsx
│   │   │   └── page.tsx
│   │   ├── api/contact/route.ts
│   │   ├── globals.css
│   │   ├── icon.svg
│   │   ├── robots.ts
│   │   └── sitemap.ts
│   ├── components/
│   │   ├── about.tsx
│   │   ├── contact-form.tsx
│   │   ├── contact.tsx
│   │   ├── cta-section.tsx
│   │   ├── footer.tsx
│   │   ├── hero.tsx
│   │   ├── hikma-logo.tsx
│   │   ├── language-switcher.tsx
│   │   ├── navbar.tsx
│   │   ├── process.tsx
│   │   ├── projects.tsx
│   │   ├── reveal.tsx
│   │   ├── section-header.tsx
│   │   ├── service-card.tsx
│   │   ├── services.tsx
│   │   ├── testimonials.tsx
│   │   └── why-hikma.tsx
│   ├── lib/
│   │   ├── i18n.ts
│   │   └── site-config.ts
│   └── proxy.ts
├── .env.example
├── .gitignore
├── eslint.config.mjs
├── next-env.d.ts
├── next.config.ts
├── package.json
├── postcss.config.mjs
├── tsconfig.json
└── README.md
```

## Recommended GitHub workflow

Create an empty repository, for example `hikma-website`, then from the project root:

```bash
git init
git add .
git commit -m "feat: launch HIKMA landing page"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/hikma-website.git
git push -u origin main
```

After the first push, keep `main` production-ready. For later design changes use branches such as:

```text
feature/projects-section
feature/real-testimonials
feature/contact-integrations
```

## Deploy to Vercel

Recommended method: Git integration.

1. Open Vercel and choose **Add New → Project**.
2. Import the GitHub repository.
3. Framework preset should be detected as **Next.js**.
4. Root Directory must stay `./`.
5. Add the environment variables listed above.
6. Deploy.
7. In **Project Settings → Git**, keep `main` as the production branch.

After that:
- push to `main` → production deployment;
- push to any other branch / open a PR → preview deployment.

## Before going live

Replace the public contact variables with real HIKMA links and set the server-only Telegram form variables.

Then verify:

```bash
npm run lint
npm run build
```

Also test:
- `/uz`, `/ru`, `/en`;
- mobile menu and language switcher;
- form delivery;
- contact links;
- `sitemap.xml` and `robots.txt`;
- Open Graph preview;
- iPhone widths around 320–430 px;
- keyboard navigation and reduced-motion mode.
