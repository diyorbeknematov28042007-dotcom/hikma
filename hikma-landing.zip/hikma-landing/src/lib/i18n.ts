export const locales = ["uz", "ru", "en"] as const;
export type Locale = (typeof locales)[number];

export function isLocale(value: string): value is Locale {
  return locales.includes(value as Locale);
}

const dictionaries = {
  uz: {
    nav: {
      home: "Bosh sahifa",
      about: "Biz haqimizda",
      services: "Xizmatlar",
      projects: "Loyihalar",
      testimonials: "Fikrlar",
      contact: "Aloqa",
      start: "Loyihani boshlash",
      openMenu: "Menyuni ochish",
      closeMenu: "Menyuni yopish",
      language: "Til",
    },
    hero: {
      badge: "Startup ekotizimi • Digital xizmatlar • AI",
      line1: "G‘oyalarni",
      line2: "raqamli yechimlarga",
      line3: "aylantiramiz.",
      text: "Hikma — startaplar, zamonaviy saytlar, Telegram botlar va raqamli reklama yechimlarini bir ekotizimda birlashtiradi.",
      primary: "Loyihani boshlash",
      secondary: "Xizmatlarni ko‘rish",
      trust: "G‘oyadan — ishlaydigan mahsulotgacha.",
      cards: ["Landing Page", "Telegram Bot", "Instagram Ads", "Telegram Ads"],
    },
    about: {
      label: "Biz haqimizda",
      titleA: "Bitta brend.",
      titleB: "Ikki kuchli yo‘nalish.",
      cards: [
        { title: "Startup ekotizimi", text: "Biz o‘z g‘oyalarimizni real raqamli mahsulotlarga aylantiramiz, sinovdan o‘tkazamiz va rivojlantiramiz." },
        { title: "Digital xizmatlar", text: "Biznes va mutaxassislar uchun sayt, bot, reklama va avtomatlashtirish yechimlarini yaratamiz." }
      ],
      flow: ["Ideya", "Dizayn", "Texnologiya", "Natija"],
    },
    services: {
      label: "Xizmatlar",
      title: "Biznesingiz uchun kerakli raqamli vositalar.",
      details: "Batafsil",
      items: [
        { id: "landing", title: "Landing Page", description: "Brendingizni professional ko‘rsatadigan, tezkor va mobil qurilmalarga mos zamonaviy sahifa.", features: ["Zamonaviy dizayn", "Mobil moslashuv", "SEO asoslari", "Domen va hosting sozlash"] },
        { id: "bot", title: "Telegram Bot", description: "Biznes jarayonlarini avtomatlashtiradigan va mijozlar bilan 24/7 ishlaydigan botlar.", features: ["Avtomatlashtirish", "Buyurtmalar", "Mijozlar bilan aloqa", "API va AI integratsiya"] },
        { id: "instagram", title: "Instagram Ads", description: "Xizmatingizni kerakli auditoriyaga olib chiqishga yo‘naltirilgan reklama kampaniyalari.", features: ["Auditoriya tahlili", "Target sozlash", "Kreativlar", "Natijalarni tahlil qilish"] },
        { id: "telegramAds", title: "Telegram Ads", description: "Telegram auditoriyasida brendingiz va taklifingizni samarali targ‘ib qilish.", features: ["Auditoriya tanlash", "Reklama strategiyasi", "Kreativ tayyorlash", "Natijalarni kuzatish"] }
      ],
    },
    projects: {
      label: "Loyihalarimiz",
      titleA: "Biz faqat xizmat ko‘rsatmaymiz.",
      titleB: "O‘z mahsulotlarimizni ham quramiz.",
      category: "LegalTech",
      project: "YURISTIM",
      status: "Rivojlanmoqda",
      description: "Huquqiy xizmatlar, AI yordamchi va raqamli yuridik vositalarni birlashtiruvchi ekotizim.",
      cta: "Barcha loyihalarni ko‘rish",
      coming: "Yangi HIKMA mahsulotlari uchun joy",
    },
    why: {
      title: "Nega Hikma?",
      items: [
        ["Individual yondashuv", "Har bir loyiha vazifasiga mos yechim."],
        ["Zamonaviy texnologiyalar", "Tezkor va rivojlantirishga tayyor mahsulotlar."],
        ["Biznesga yo‘naltirilgan", "Dizayn uchun dizayn emas — aniq maqsad uchun yechim."],
        ["Bir ekotizim", "Saytdan botgacha, reklamadan avtomatlashtirishgacha."]
      ],
    },
    process: {
      title: "G‘oyadan natijagacha.",
      items: [
        ["Tanishuv", "Maqsad va vazifani tushunamiz."],
        ["Reja", "Eng maqbul yechimni shakllantiramiz."],
        ["Ishlab chiqish", "Dizayn va texnologiyani birlashtiramiz."],
        ["Ishga tushirish", "Loyihani real foydalanishga chiqaramiz."],
        ["Qo‘llab-quvvatlash", "Zarur bo‘lsa rivojlantirishda davom etamiz."]
      ],
    },
    testimonials: {
      label: "Fikrlar",
      title: "Biz bilan ishlaganlar nima deydi?",
      placeholder: "Mijoz fikri shu yerda joylashadi.",
      hint: "Instagram yoki Telegram yozishmasi skrinshoti uchun joy.",
    },
    cta: {
      title: "G‘oyangiz bormi?",
      text: "Uni raqamli mahsulotga aylantirishni birgalikda boshlaymiz.",
      primary: "Biz bilan bog‘lanish",
      secondary: "Telegram orqali yozish",
    },
    contact: {
      title: "Bog‘lanish",
      intro: "Loyihangiz haqida qisqacha yozing. Biz sizga mos yo‘nalishni aniqlashdan boshlaymiz.",
      telegram: "Telegram",
      instagram: "Instagram",
      email: "Email",
      form: {
        name: "Ismingiz",
        contact: "Aloqa uchun Telegram yoki telefon",
        service: "Qaysi xizmat kerak?",
        message: "Loyiha haqida qisqacha",
        submit: "Yuborish",
        sending: "Yuborilmoqda...",
        choose: "Xizmatni tanlang",
        services: ["Landing Page", "Telegram Bot", "Instagram Ads", "Telegram Ads", "Boshqa"],
        success: "So‘rovingiz yuborildi. Tez orada bog‘lanamiz.",
        error: "Xatolik yuz berdi. Ma’lumotlarni tekshirib qayta urinib ko‘ring.",
      },
    },
    footer: {
      text: "Hikma — millat uchun raqamli yechimlar.",
      rights: "© 2026 Hikma. Barcha huquqlar himoyalangan.",
    },
  },
  ru: {
    nav: {
      home: "Главная", about: "О нас", services: "Услуги", projects: "Проекты", testimonials: "Отзывы", contact: "Контакты",
      start: "Начать проект", openMenu: "Открыть меню", closeMenu: "Закрыть меню", language: "Язык",
    },
    hero: {
      badge: "Стартап-экосистема • Digital-услуги • AI",
      line1: "Превращаем идеи", line2: "в цифровые решения", line3: "которые работают.",
      text: "Hikma объединяет стартапы, современные сайты, Telegram-боты и решения цифровой рекламы в одной экосистеме.",
      primary: "Начать проект", secondary: "Смотреть услуги", trust: "От идеи — до работающего продукта.",
      cards: ["Landing Page", "Telegram Bot", "Instagram Ads", "Telegram Ads"],
    },
    about: {
      label: "О нас", titleA: "Один бренд.", titleB: "Два сильных направления.",
      cards: [
        { title: "Стартап-экосистема", text: "Мы превращаем собственные идеи в реальные цифровые продукты, тестируем и развиваем их." },
        { title: "Digital-услуги", text: "Создаём сайты, ботов, рекламу и автоматизацию для бизнеса и специалистов." }
      ],
      flow: ["Идея", "Дизайн", "Технология", "Результат"],
    },
    services: {
      label: "Услуги", title: "Цифровые инструменты, которые нужны вашему бизнесу.", details: "Подробнее",
      items: [
        { id: "landing", title: "Landing Page", description: "Современная быстрая страница, которая профессионально представляет бренд и отлично работает на мобильных устройствах.", features: ["Современный дизайн", "Адаптивность", "Основы SEO", "Настройка домена и хостинга"] },
        { id: "bot", title: "Telegram Bot", description: "Боты, которые автоматизируют бизнес-процессы и помогают работать с клиентами 24/7.", features: ["Автоматизация", "Заказы", "Коммуникация с клиентами", "API и AI-интеграции"] },
        { id: "instagram", title: "Instagram Ads", description: "Рекламные кампании, нацеленные на релевантную аудиторию вашего предложения.", features: ["Анализ аудитории", "Настройка таргета", "Креативы", "Анализ результатов"] },
        { id: "telegramAds", title: "Telegram Ads", description: "Продвижение бренда и предложения среди аудитории Telegram с понятной стратегией.", features: ["Выбор аудитории", "Рекламная стратегия", "Подготовка креативов", "Отслеживание результатов"] }
      ],
    },
    projects: {
      label: "Наши проекты", titleA: "Мы не только оказываем услуги.", titleB: "Мы создаём собственные продукты.",
      category: "LegalTech", project: "YURISTIM", status: "В разработке",
      description: "Экосистема, объединяющая юридические услуги, AI-помощника и цифровые инструменты для права.",
      cta: "Смотреть все проекты", coming: "Место для новых продуктов HIKMA",
    },
    why: {
      title: "Почему Hikma?",
      items: [
        ["Индивидуальный подход", "Решение под конкретную задачу каждого проекта."],
        ["Современные технологии", "Быстрые продукты с запасом для дальнейшего развития."],
        ["Фокус на бизнесе", "Не дизайн ради дизайна — решение ради конкретной цели."],
        ["Одна экосистема", "От сайта и бота до рекламы и автоматизации."]
      ],
    },
    process: {
      title: "От идеи до результата.",
      items: [
        ["Знакомство", "Понимаем цель и задачу."],
        ["План", "Формируем оптимальное решение."],
        ["Разработка", "Объединяем дизайн и технологию."],
        ["Запуск", "Выводим проект в реальное использование."],
        ["Поддержка", "При необходимости продолжаем развивать продукт."]
      ],
    },
    testimonials: {
      label: "Отзывы", title: "Что говорят те, кто работал с нами?",
      placeholder: "Здесь будет размещён отзыв клиента.",
      hint: "Место для скриншота переписки из Instagram или Telegram.",
    },
    cta: {
      title: "Есть идея?", text: "Давайте вместе начнём превращать её в цифровой продукт.",
      primary: "Связаться с нами", secondary: "Написать в Telegram",
    },
    contact: {
      title: "Связаться", intro: "Кратко расскажите о проекте. Начнём с определения подходящего решения.",
      telegram: "Telegram", instagram: "Instagram", email: "Email",
      form: {
        name: "Ваше имя", contact: "Telegram или телефон для связи", service: "Какая услуга нужна?",
        message: "Кратко о проекте", submit: "Отправить", sending: "Отправляем...", choose: "Выберите услугу",
        services: ["Landing Page", "Telegram Bot", "Instagram Ads", "Telegram Ads", "Другое"],
        success: "Заявка отправлена. Мы скоро свяжемся с вами.",
        error: "Произошла ошибка. Проверьте данные и попробуйте ещё раз.",
      },
    },
    footer: {
      text: "Hikma — цифровые решения для будущего страны.",
      rights: "© 2026 Hikma. Все права защищены.",
    },
  },
  en: {
    nav: {
      home: "Home", about: "About", services: "Services", projects: "Projects", testimonials: "Reviews", contact: "Contact",
      start: "Start a project", openMenu: "Open menu", closeMenu: "Close menu", language: "Language",
    },
    hero: {
      badge: "Startup ecosystem • Digital services • AI",
      line1: "We turn ideas", line2: "into digital solutions", line3: "that work.",
      text: "Hikma brings startups, modern websites, Telegram bots and digital advertising solutions into one ecosystem.",
      primary: "Start a project", secondary: "View services", trust: "From an idea — to a working product.",
      cards: ["Landing Page", "Telegram Bot", "Instagram Ads", "Telegram Ads"],
    },
    about: {
      label: "About us", titleA: "One brand.", titleB: "Two powerful directions.",
      cards: [
        { title: "Startup ecosystem", text: "We turn our own ideas into real digital products, test them and keep developing them." },
        { title: "Digital services", text: "We build websites, bots, advertising and automation solutions for businesses and professionals." }
      ],
      flow: ["Idea", "Design", "Technology", "Result"],
    },
    services: {
      label: "Services", title: "The digital tools your business needs.", details: "Learn more",
      items: [
        { id: "landing", title: "Landing Page", description: "A modern, fast and mobile-ready page that presents your brand professionally.", features: ["Modern design", "Mobile responsive", "SEO foundations", "Domain and hosting setup"] },
        { id: "bot", title: "Telegram Bot", description: "Bots that automate business processes and help you work with customers 24/7.", features: ["Automation", "Orders", "Customer communication", "API and AI integration"] },
        { id: "instagram", title: "Instagram Ads", description: "Advertising campaigns designed to reach a relevant audience for your offer.", features: ["Audience analysis", "Targeting setup", "Creative production", "Performance analysis"] },
        { id: "telegramAds", title: "Telegram Ads", description: "Strategic promotion of your brand and offer across Telegram audiences.", features: ["Audience selection", "Ad strategy", "Creative preparation", "Performance tracking"] }
      ],
    },
    projects: {
      label: "Our projects", titleA: "We do more than provide services.", titleB: "We build our own products too.",
      category: "LegalTech", project: "YURISTIM", status: "In development",
      description: "An ecosystem combining legal services, an AI assistant and digital tools for legal work.",
      cta: "View all projects", coming: "Space for upcoming HIKMA products",
    },
    why: {
      title: "Why Hikma?",
      items: [
        ["Individual approach", "A solution shaped around each project’s real task."],
        ["Modern technology", "Fast products designed for future development."],
        ["Business-focused", "Not design for design’s sake — solutions built around a goal."],
        ["One ecosystem", "From websites and bots to advertising and automation."]
      ],
    },
    process: {
      title: "From idea to result.",
      items: [
        ["Discovery", "We understand the goal and the task."],
        ["Plan", "We shape the most practical solution."],
        ["Build", "We combine design and technology."],
        ["Launch", "We bring the project into real-world use."],
        ["Support", "When needed, we continue developing the product."]
      ],
    },
    testimonials: {
      label: "Reviews", title: "What do people say about working with us?",
      placeholder: "A client testimonial will be placed here.",
      hint: "Space for an Instagram or Telegram message screenshot.",
    },
    cta: {
      title: "Have an idea?", text: "Let’s start turning it into a digital product together.",
      primary: "Contact us", secondary: "Message on Telegram",
    },
    contact: {
      title: "Contact", intro: "Tell us briefly about your project. We’ll start by identifying the right direction.",
      telegram: "Telegram", instagram: "Instagram", email: "Email",
      form: {
        name: "Your name", contact: "Telegram or phone number", service: "Which service do you need?",
        message: "Briefly about the project", submit: "Send", sending: "Sending...", choose: "Choose a service",
        services: ["Landing Page", "Telegram Bot", "Instagram Ads", "Telegram Ads", "Other"],
        success: "Your request has been sent. We’ll contact you soon.",
        error: "Something went wrong. Check the details and try again.",
      },
    },
    footer: {
      text: "Hikma — digital solutions for the nation.",
      rights: "© 2026 Hikma. All rights reserved.",
    },
  },
} as const;

export function getDictionary(locale: Locale) {
  return dictionaries[locale];
}
