import { NextResponse } from "next/server";

const allowedServices = new Set([
  "landing-page",
  "telegram-bot",
  "instagram-ads",
  "telegram-ads",
  "other",
]);

type ContactPayload = {
  name?: unknown;
  contact?: unknown;
  service?: unknown;
  message?: unknown;
  website?: unknown;
};

function cleanString(value: unknown, max: number) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  const expectedOrigin = new URL(request.url).origin;
  if (origin && origin !== expectedOrigin) {
    return NextResponse.json({ ok: false, code: "ORIGIN_REJECTED" }, { status: 403 });
  }

  let body: ContactPayload;

  try {
    body = (await request.json()) as ContactPayload;
  } catch {
    return NextResponse.json({ ok: false, code: "INVALID_JSON" }, { status: 400 });
  }

  // Honeypot for basic bot filtering.
  if (cleanString(body.website, 200)) {
    return NextResponse.json({ ok: true });
  }

  const name = cleanString(body.name, 80);
  const contact = cleanString(body.contact, 120);
  const service = cleanString(body.service, 40);
  const message = cleanString(body.message, 1500);

  if (
    name.length < 2 ||
    contact.length < 3 ||
    message.length < 10 ||
    !allowedServices.has(service)
  ) {
    return NextResponse.json({ ok: false, code: "VALIDATION_ERROR" }, { status: 400 });
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.error("HIKMA contact form: Telegram delivery environment variables are missing.");
    return NextResponse.json({ ok: false, code: "DELIVERY_NOT_CONFIGURED" }, { status: 503 });
  }

  const text = [
    "🟢 HIKMA — yangi so‘rov",
    "",
    `Ism: ${name}`,
    `Aloqa: ${contact}`,
    `Xizmat: ${service}`,
    "",
    "Loyiha:",
    message,
  ].join("\n");

  try {
    const telegramResponse = await fetch(
      `https://api.telegram.org/bot${token}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          disable_web_page_preview: true,
        }),
        cache: "no-store",
      }
    );

    if (!telegramResponse.ok) {
      const detail = await telegramResponse.text();
      console.error("HIKMA contact form: Telegram delivery failed.", detail);
      return NextResponse.json({ ok: false, code: "DELIVERY_FAILED" }, { status: 502 });
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("HIKMA contact form: unexpected delivery error.", error);
    return NextResponse.json({ ok: false, code: "DELIVERY_FAILED" }, { status: 502 });
  }
}
