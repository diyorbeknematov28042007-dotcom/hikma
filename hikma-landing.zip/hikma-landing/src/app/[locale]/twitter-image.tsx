import { ImageResponse } from "next/og";
import { isLocale, type Locale } from "@/lib/i18n";

export const alt = "HIKMA";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

const copy: Record<Locale, { eyebrow: string; line1: string; line2: string }> = {
  uz: {
    eyebrow: "Startup ekotizimi • Digital xizmatlar • AI",
    line1: "G‘oyalarni raqamli",
    line2: "yechimlarga aylantiramiz.",
  },
  ru: {
    eyebrow: "Стартап-экосистема • Digital-услуги • AI",
    line1: "Превращаем идеи",
    line2: "в цифровые решения.",
  },
  en: {
    eyebrow: "Startup ecosystem • Digital services • AI",
    line1: "We turn ideas into",
    line2: "digital solutions.",
  },
};

export default async function Image({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale: rawLocale } = await params;
  const locale: Locale = isLocale(rawLocale) ? rawLocale : "uz";
  const t = copy[locale];

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "#FFFFFF",
          color: "#101828",
          padding: "72px 84px",
          position: "relative",
          overflow: "hidden",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <div
          style={{
            position: "absolute",
            width: 430,
            height: 430,
            borderRadius: 999,
            background: "#E8F7F0",
            right: -100,
            top: -150,
          }}
        />
        <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
          <div
            style={{
              width: 92,
              height: 92,
              borderRadius: 28,
              background: "#079455",
              color: "white",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontWeight: 900,
              fontSize: 48,
            }}
          >
            H
          </div>
          <div style={{ display: "flex", fontSize: 48, fontWeight: 900, letterSpacing: 10 }}>
            HIKMA
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", maxWidth: 980 }}>
          <div style={{ fontSize: 72, fontWeight: 900, letterSpacing: -3, lineHeight: 1.04 }}>
            {t.line1}
          </div>
          <div style={{ fontSize: 72, fontWeight: 900, letterSpacing: -3, lineHeight: 1.04, color: "#079455" }}>
            {t.line2}
          </div>
        </div>

        <div style={{ display: "flex", fontSize: 27, color: "#667085", fontWeight: 600 }}>
          {t.eyebrow}
        </div>
      </div>
    ),
    size
  );
}
