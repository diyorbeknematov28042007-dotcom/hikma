import { notFound } from "next/navigation";
import { About } from "@/components/about";
import { Contact } from "@/components/contact";
import { CTASection } from "@/components/cta-section";
import { Footer } from "@/components/footer";
import { Hero } from "@/components/hero";
import { Navbar } from "@/components/navbar";
import { Process } from "@/components/process";
import { Projects } from "@/components/projects";
import { Services } from "@/components/services";
import { Testimonials } from "@/components/testimonials";
import { WhyHikma } from "@/components/why-hikma";
import { getDictionary, isLocale, type Locale } from "@/lib/i18n";
import { getBaseUrl } from "@/lib/site-config";

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();

  const currentLocale = locale as Locale;
  const t = getDictionary(currentLocale);
  const baseUrl = getBaseUrl();

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "HIKMA",
    url: `${baseUrl}/${locale}`,
    description: t.hero.text,
    knowsAbout: [
      "Web Development",
      "Telegram Bots",
      "Artificial Intelligence",
      "Automation",
      "Instagram Ads",
      "Telegram Ads",
      "Startups",
    ],
  };

  return (
    <>
      <Navbar locale={currentLocale} copy={t.nav} />
      <main>
        <Hero copy={t.hero} />
        <About copy={t.about} />
        <Services copy={t.services} />
        <Projects copy={t.projects} />
        <WhyHikma copy={t.why} />
        <Process copy={t.process} />
        <Testimonials copy={t.testimonials} />
        <CTASection copy={t.cta} />
        <Contact copy={t.contact} />
      </main>
      <Footer copy={t.footer} nav={t.nav} />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
    </>
  );
}
