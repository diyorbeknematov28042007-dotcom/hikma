import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Geist, Geist_Mono } from "next/font/google";
import { notFound } from "next/navigation";
import "../globals.css";
import { isLocale, locales, type Locale } from "@/lib/i18n";
import { getBaseUrl } from "@/lib/site-config";

const geist = Geist({
  subsets: ["latin", "cyrillic"],
  variable: "--font-geist-sans",
  display: "swap",
});

const geistMono = Geist_Mono({
  subsets: ["latin", "cyrillic"],
  variable: "--font-geist-mono",
  display: "swap",
});

const metadataByLocale: Record<Locale, { title: string; description: string }> = {
  uz: {
    title: "Hikma — Saytlar, Telegram Botlar va Raqamli Xizmatlar",
    description:
      "Hikma — startup ekotizimi va raqamli xizmatlar studiyasi. Landing page, Telegram bot, Instagram Ads, Telegram Ads va zamonaviy digital yechimlar.",
  },
  ru: {
    title: "Hikma — сайты, Telegram-боты и цифровые услуги",
    description:
      "Hikma — стартап-экосистема и студия цифровых услуг: landing page, Telegram-боты, Instagram Ads, Telegram Ads и современные digital-решения.",
  },
  en: {
    title: "Hikma — Websites, Telegram Bots and Digital Services",
    description:
      "Hikma is a startup ecosystem and digital product studio for landing pages, Telegram bots, Instagram Ads, Telegram Ads and modern digital solutions.",
  },
};

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale: rawLocale } = await params;
  if (!isLocale(rawLocale)) notFound();

  const locale = rawLocale as Locale;
  const meta = metadataByLocale[locale];
  const baseUrl = getBaseUrl();

  return {
    metadataBase: new URL(baseUrl),
    title: meta.title,
    description: meta.description,
    applicationName: "HIKMA",
    alternates: {
      canonical: `/${locale}`,
      languages: {
        uz: "/uz",
        ru: "/ru",
        en: "/en",
        "x-default": "/uz",
      },
    },
    openGraph: {
      type: "website",
      locale: locale === "uz" ? "uz_UZ" : locale === "ru" ? "ru_RU" : "en_US",
      url: `/${locale}`,
      siteName: "HIKMA",
      title: meta.title,
      description: meta.description,
    },
    twitter: {
      card: "summary_large_image",
      title: meta.title,
      description: meta.description,
    },
    robots: {
      index: true,
      follow: true,
    },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: Readonly<{
  children: ReactNode;
  params: Promise<{ locale: string }>;
}>) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();

  return (
    <html lang={locale} className={`${geist.variable} ${geistMono.variable}`}>
      <body>{children}</body>
    </html>
  );
}
