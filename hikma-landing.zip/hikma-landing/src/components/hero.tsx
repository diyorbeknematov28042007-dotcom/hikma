import {
  Bot,
  ChartNoAxesCombined,
  Globe2,
  Instagram,
  MoveRight,
  Send,
  Sparkles,
} from "lucide-react";
import { Reveal } from "./reveal";

type HeroCopy = {
  badge: string;
  line1: string;
  line2: string;
  line3: string;
  text: string;
  primary: string;
  secondary: string;
  trust: string;
  cards: readonly string[];
};

const cards = [
  { icon: Globe2, pos: "left-0 top-6 sm:left-4", tone: "bg-white" },
  { icon: Bot, pos: "right-0 top-16 sm:right-2", tone: "bg-white" },
  { icon: Instagram, pos: "bottom-16 left-2 sm:left-12", tone: "bg-white" },
  { icon: Send, pos: "bottom-2 right-2 sm:right-16", tone: "bg-white" },
];

export function Hero({ copy }: { copy: HeroCopy }) {
  return (
    <section id="home" className="relative overflow-hidden pb-20 pt-36 sm:pb-28 sm:pt-44">
      <div className="hero-grid absolute inset-0 -z-20 opacity-70" />
      <div className="absolute -left-24 top-24 -z-10 h-72 w-72 rounded-full bg-[#E8F7F0] blur-3xl" />
      <div className="absolute right-[-8rem] top-16 -z-10 h-96 w-96 rounded-full bg-[#F4FBF7] blur-2xl" />

      <div className="section-shell grid items-center gap-16 lg:grid-cols-[1.04fr_.96fr]">
        <Reveal>
          <div className="inline-flex items-center gap-2 rounded-full border border-[#079455]/15 bg-white/80 px-3 py-2 text-xs font-extrabold text-[#046C45] shadow-sm backdrop-blur">
            <Sparkles size={14} className="text-[#079455]" />
            {copy.badge}
          </div>

          <h1 className="mt-6 max-w-4xl text-balance text-[clamp(3.2rem,7vw,6.6rem)] font-black leading-[0.93] tracking-[-0.065em] text-[#101828]">
            <span className="block">{copy.line1}</span>
            <span className="block text-[#079455]">{copy.line2}</span>
            <span className="block">{copy.line3}</span>
          </h1>

          <p className="mt-7 max-w-2xl text-base leading-7 text-[#667085] sm:text-lg sm:leading-8">
            {copy.text}
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a href="#contact" className="btn-primary group">
              {copy.primary}
              <MoveRight size={18} className="transition group-hover:translate-x-1" />
            </a>
            <a href="#services" className="btn-secondary">
              {copy.secondary}
            </a>
          </div>

          <div className="mt-7 flex items-center gap-2 text-sm font-semibold text-[#667085]">
            <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-[#E8F7F0] text-[#079455]">✓</span>
            {copy.trust}
          </div>
        </Reveal>

        <Reveal delay={120} className="relative">
          <div className="relative mx-auto aspect-square w-full max-w-[620px]">
            <div className="absolute inset-[13%] rounded-full border border-[#079455]/10 bg-white/60 shadow-[0_40px_100px_rgba(7,148,85,.12)] backdrop-blur-md" />
            <div className="absolute inset-[24%] rounded-full border border-[#079455]/15 bg-[#F4FBF7]" />
            <div className="logo-orbit absolute inset-[35%] flex items-center justify-center rounded-[2.2rem] bg-[#079455] shadow-[0_28px_70px_rgba(7,148,85,.25)]">
              <div className="relative h-20 w-24">
                <span className="absolute left-1 top-1/2 block h-5 w-20 -translate-y-1/2 rotate-[52deg] rounded-full bg-white" />
                <span className="absolute right-1 top-1/2 block h-5 w-20 -translate-y-1/2 -rotate-[52deg] rounded-full bg-[#DDF5E9]" />
              </div>
            </div>

            <div className="absolute left-[12%] top-[15%] h-14 w-14 rounded-full border border-[#079455]/10 bg-[#E8F7F0]" />
            <div className="absolute bottom-[15%] right-[14%] h-8 w-8 rounded-xl border border-[#079455]/10 bg-white shadow-md" />
            <div className="absolute right-[17%] top-[6%] text-[#079455]/40">
              <ChartNoAxesCombined size={38} strokeWidth={1.5} />
            </div>

            {cards.map(({ icon: Icon, pos }, index) => (
              <div
                key={copy.cards[index]}
                className={`floating-card absolute ${pos} z-20 min-w-[150px] rounded-2xl border border-[#079455]/15 bg-white/95 p-3 shadow-[0_18px_50px_rgba(16,24,40,.10)] backdrop-blur sm:min-w-[180px] sm:p-4`}
                style={{ animationDelay: `${index * 0.45}s` }}
              >
                <div className="flex items-center gap-3">
                  <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#E8F7F0] text-[#079455]">
                    <Icon size={20} />
                  </span>
                  <div>
                    <p className="text-xs font-semibold text-[#98A2B3]">HIKMA</p>
                    <p className="text-sm font-extrabold text-[#101828]">{copy.cards[index]}</p>
                  </div>
                </div>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-[#F2F4F7]">
                  <div className="h-full rounded-full bg-[#079455]" style={{ width: `${58 + index * 9}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
