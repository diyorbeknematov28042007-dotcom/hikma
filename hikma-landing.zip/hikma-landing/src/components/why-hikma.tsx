import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";

type WhyCopy = {
  title: string;
  items: readonly (readonly [string, string])[];
};

export function WhyHikma({ copy }: { copy: WhyCopy }) {
  return (
    <section className="section-space bg-[#071D14] text-white">
      <div className="section-shell">
        <Reveal>
          <SectionHeader title={<span className="text-white">{copy.title}</span>} />
        </Reveal>
        <div className="mt-10 grid gap-px overflow-hidden rounded-[2rem] border border-white/10 bg-white/10 md:grid-cols-2 xl:grid-cols-4">
          {copy.items.map(([title, text], index) => (
            <Reveal key={title} delay={index * 60}>
              <article className="h-full bg-[#071D14] p-6 sm:p-7">
                <div className="text-5xl font-black tracking-[-0.06em] text-[#34D399]">{String(index + 1).padStart(2, "0")}</div>
                <h3 className="mt-8 text-xl font-extrabold">{title}</h3>
                <p className="mt-3 leading-7 text-white/60">{text}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
