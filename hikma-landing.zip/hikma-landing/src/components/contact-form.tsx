"use client";

import { FormEvent, useState } from "react";
import { LoaderCircle, Send } from "lucide-react";

type FormCopy = {
  name: string;
  contact: string;
  service: string;
  message: string;
  submit: string;
  sending: string;
  choose: string;
  services: readonly string[];
  success: string;
  error: string;
};

const slugs = ["landing-page", "telegram-bot", "instagram-ads", "telegram-ads", "other"] as const;

export function ContactForm({ copy }: { copy: FormCopy }) {
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("sending");

    const form = event.currentTarget;
    const data = new FormData(form);

    const payload = {
      name: String(data.get("name") ?? "").trim(),
      contact: String(data.get("contact") ?? "").trim(),
      service: String(data.get("service") ?? ""),
      message: String(data.get("message") ?? "").trim(),
      website: String(data.get("website") ?? ""),
    };

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error("Request failed");
      setStatus("success");
      form.reset();
    } catch {
      setStatus("error");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-[2rem] border border-[#079455]/12 bg-white p-5 shadow-[0_24px_70px_rgba(16,24,40,.07)] sm:p-7">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="field-label">
          <span>{copy.name}</span>
          <input name="name" required minLength={2} maxLength={80} autoComplete="name" className="field-input" />
        </label>

        <label className="field-label">
          <span>{copy.contact}</span>
          <input name="contact" required minLength={3} maxLength={120} autoComplete="tel" className="field-input" />
        </label>
      </div>

      <label className="field-label mt-5">
        <span>{copy.service}</span>
        <select name="service" required defaultValue="" className="field-input">
          <option value="" disabled>{copy.choose}</option>
          {copy.services.map((label, index) => (
            <option key={label} value={slugs[index]}>{label}</option>
          ))}
        </select>
      </label>

      <label className="field-label mt-5">
        <span>{copy.message}</span>
        <textarea name="message" required minLength={10} maxLength={1500} rows={5} className="field-input resize-y" />
      </label>

      <label className="sr-only" aria-hidden="true">
        Website
        <input name="website" tabIndex={-1} autoComplete="off" />
      </label>

      <button type="submit" disabled={status === "sending"} className="btn-primary mt-6 w-full sm:w-auto">
        {status === "sending" ? (
          <>
            <LoaderCircle size={18} className="animate-spin" />
            {copy.sending}
          </>
        ) : (
          <>
            <Send size={18} />
            {copy.submit}
          </>
        )}
      </button>

      <div aria-live="polite" className="mt-4 min-h-6 text-sm font-semibold">
        {status === "success" && <p className="text-[#079455]">{copy.success}</p>}
        {status === "error" && <p className="text-red-600">{copy.error}</p>}
      </div>
    </form>
  );
}
