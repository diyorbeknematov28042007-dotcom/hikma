"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { Locale } from "@/lib/i18n";

export function LanguageSwitcher({ locale, label }: { locale: Locale; label: string }) {
  const pathname = usePathname();

  function localizedPath(nextLocale: Locale) {
    const parts = pathname.split("/").filter(Boolean);
    if (parts[0] === "uz" || parts[0] === "ru" || parts[0] === "en") {
      parts[0] = nextLocale;
      return `/${parts.join("/")}`;
    }
    return `/${nextLocale}`;
  }

  return (
    <div className="flex items-center gap-1 rounded-full border border-[#079455]/15 bg-white/80 p-1 shadow-sm" aria-label={label}>
      {(["uz", "ru", "en"] as Locale[]).map((item) => (
        <Link
          key={item}
          href={localizedPath(item)}
          className={`rounded-full px-2.5 py-1.5 text-xs font-bold uppercase transition ${
            item === locale
              ? "bg-[#079455] text-white shadow-sm"
              : "text-[#667085] hover:bg-[#E8F7F0] hover:text-[#046C45]"
          }`}
          aria-current={item === locale ? "page" : undefined}
        >
          {item}
        </Link>
      ))}
    </div>
  );
}
