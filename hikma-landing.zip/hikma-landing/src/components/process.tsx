import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";

type ProcessCopy = {
  title: string;
  items: readonly (readonly [string, string])[];
};

export function Process({ copy }: { copy: ProcessCopy }) {
  return (
    <section className="section-space">
      <div className="section-shell">
        <Reveal>
          <SectionHeader title={copy.title} />
        </Reveal>

        <div className="relative mt-12">
          <div className="absolute left-[1.15rem] top-0 hidden h-full w-px bg-[#079455]/20 sm:block md:hidden" />
          <div className="absolute left-[8%] right-[8%] top-6 hidden h-px bg-[#079455]/20 md:block" />

          <div className="grid gap-5 md:grid-cols-5">
            {copy.items.map(([title, text], index) => (
              <Reveal key={title} delay={index * 60}>
                <article className="relative flex gap-4 md:block">
                  <div className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border border-[#079455]/20 bg-white text-sm font-black text-[#079455] shadow-sm md:mx-auto">
                    {String(index + 1).padStart(2, "0")}
                  </div>
                  <div className="pt-1 md:pt-6 md:text-center">
                    <h3 className="font-extrabold text-[#101828]">{title}</h3>
                    <p className="mt-2 text-sm leading-6 text-[#667085]">{text}</p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
