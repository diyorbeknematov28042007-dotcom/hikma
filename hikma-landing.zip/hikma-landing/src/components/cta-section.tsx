import { ArrowUpRight, Send } from "lucide-react";
import { siteConfig } from "@/lib/site-config";
import { Reveal } from "./reveal";

type CtaCopy = {
  title: string;
  text: string;
  primary: string;
  secondary: string;
};

export function CTASection({ copy }: { copy: CtaCopy }) {
  const telegramHref = siteConfig.telegramUrl || "#contact";

  return (
    <section className="py-10 sm:py-14">
      <div className="section-shell">
        <Reveal>
          <div className="cta-pattern relative overflow-hidden rounded-[2.5rem] bg-[#046C45] px-6 py-12 text-white shadow-[0_30px_90px_rgba(4,108,69,.22)] sm:px-10 sm:py-16 lg:px-16">
            <div className="relative z-10 max-w-3xl">
              <h2 className="text-balance text-4xl font-black tracking-[-0.05em] sm:text-5xl lg:text-6xl">{copy.title}</h2>
              <p className="mt-4 max-w-2xl text-base leading-7 text-white/75 sm:text-lg">{copy.text}</p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <a href="#contact" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-white px-6 py-3 font-extrabold text-[#046C45] transition hover:bg-[#E8F7F0]">
                  {copy.primary}
                  <ArrowUpRight size={18} />
                </a>
                <a href={telegramHref} target={siteConfig.telegramUrl ? "_blank" : undefined} rel="noreferrer" className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-white/25 bg-white/10 px-6 py-3 font-extrabold text-white transition hover:bg-white/15">
                  <Send size={18} />
                  {copy.secondary}
                </a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
