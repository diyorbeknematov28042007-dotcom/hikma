type LogoProps = {
  compact?: boolean;
  inverted?: boolean;
  className?: string;
};

export function HikmaLogo({ compact = false, inverted = false, className = "" }: LogoProps) {
  const textColor = inverted ? "text-white" : "text-[#101828]";
  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`} aria-label="HIKMA">
      <svg
        viewBox="0 0 48 48"
        className="h-9 w-9 shrink-0"
        role="img"
        aria-hidden="true"
      >
        <rect width="48" height="48" rx="14" fill={inverted ? "#FFFFFF" : "#079455"} />
        <path d="M12 13h8l8 11-8 11h-8l8-11-8-11Z" fill={inverted ? "#079455" : "#FFFFFF"} opacity=".98" />
        <path d="M36 13h-8L20 24l8 11h8l-8-11 8-11Z" fill={inverted ? "#046C45" : "#DDF5E9"} opacity=".95" />
      </svg>
      {!compact && (
        <span className={`text-lg font-black tracking-[0.24em] ${textColor}`}>
          HIKMA
        </span>
      )}
    </div>
  );
}
