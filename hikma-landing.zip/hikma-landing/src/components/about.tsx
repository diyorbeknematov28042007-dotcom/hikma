import { Boxes, Rocket, Waypoints } from "lucide-react";
import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";

type AboutCopy = {
  label: string;
  titleA: string;
  titleB: string;
  cards: readonly { title: string; text: string }[];
  flow: readonly string[];
};

export function About({ copy }: { copy: AboutCopy }) {
  return (
    <section id="about" className="section-space">
      <div className="section-shell">
        <Reveal>
          <SectionHeader
            label={copy.label}
            title={
              <>
                {copy.titleA} <span className="text-[#079455]">{copy.titleB}</span>
              </>
            }
          />
        </Reveal>

        <div className="mt-10 grid gap-5 lg:grid-cols-2">
          {copy.cards.map((card, index) => {
            const Icon = index === 0 ? Rocket : Boxes;
            return (
              <Reveal key={card.title} delay={index * 80}>
                <article className="group h-full rounded-[2rem] border border-[#079455]/12 bg-white p-6 shadow-[0_18px_60px_rgba(16,24,40,.06)] transition duration-300 hover:-translate-y-1 hover:border-[#079455]/30 sm:p-8">
                  <div className="relative overflow-hidden rounded-[1.5rem] border border-[#079455]/10 bg-[#F4FBF7] p-6">
                    <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full border-[18px] border-[#079455]/5" />
                    <div className="relative flex h-24 items-center justify-center">
                      <span className="absolute h-20 w-20 rotate-12 rounded-[1.5rem] bg-[#E8F7F0]" />
                      <span className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-[#079455] text-white shadow-[0_18px_40px_rgba(7,148,85,.2)]">
                        <Icon size={30} />
                      </span>
                    </div>
                  </div>
                  <h3 className="mt-6 text-2xl font-black tracking-[-0.03em] text-[#101828]">{card.title}</h3>
                  <p className="mt-3 max-w-xl leading-7 text-[#667085]">{card.text}</p>
                </article>
              </Reveal>
            );
          })}
        </div>

        <Reveal className="mt-10">
          <div className="rounded-[2rem] border border-[#079455]/10 bg-[#F4FBF7] p-5 sm:p-7">
            <div className="flex flex-col items-stretch justify-between gap-4 md:flex-row md:items-center">
              {copy.flow.map((item, index) => (
                <div key={item} className="flex flex-1 items-center gap-4">
                  <div className="flex min-w-0 flex-1 items-center gap-3 rounded-2xl bg-white px-4 py-4 shadow-sm">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#E8F7F0] text-[#079455]">
                      <Waypoints size={18} />
                    </span>
                    <span className="font-extrabold text-[#344054]">{item}</span>
                  </div>
                  {index < copy.flow.length - 1 && (
                    <span className="hidden h-px w-8 shrink-0 bg-[#079455]/25 md:block" />
                  )}
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
