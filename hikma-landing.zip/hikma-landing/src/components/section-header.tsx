import type { ReactNode } from "react";

export function SectionHeader({
  label,
  title,
  align = "left",
}: {
  label?: string;
  title: ReactNode;
  align?: "left" | "center";
}) {
  return (
    <div className={`max-w-3xl ${align === "center" ? "mx-auto text-center" : ""}`}>
      {label && (
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-[#079455]/15 bg-[#F4FBF7] px-3 py-1.5 text-xs font-extrabold uppercase tracking-[0.14em] text-[#079455]">
          <span className="h-1.5 w-1.5 rounded-full bg-[#079455]" />
          {label}
        </div>
      )}
      <h2 className="text-balance text-3xl font-black tracking-[-0.04em] text-[#101828] sm:text-4xl lg:text-5xl">
        {title}
      </h2>
    </div>
  );
}
