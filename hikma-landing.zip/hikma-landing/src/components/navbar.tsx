"use client";

import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import type { Locale } from "@/lib/i18n";
import { HikmaLogo } from "./hikma-logo";
import { LanguageSwitcher } from "./language-switcher";

type NavCopy = {
  home: string;
  about: string;
  services: string;
  projects: string;
  testimonials: string;
  contact: string;
  start: string;
  openMenu: string;
  closeMenu: string;
  language: string;
};

export function Navbar({ locale, copy }: { locale: Locale; copy: NavCopy }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 18);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    ["#home", copy.home],
    ["#about", copy.about],
    ["#services", copy.services],
    ["#projects", copy.projects],
    ["#testimonials", copy.testimonials],
    ["#contact", copy.contact],
  ] as const;

  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${scrolled ? "py-2" : "py-4"}`}>
      <div
        className={`mx-auto flex max-w-7xl items-center justify-between px-4 transition-all sm:px-6 lg:px-8 ${
          scrolled
            ? "rounded-2xl border border-white/80 bg-white/85 py-2.5 shadow-[0_12px_40px_rgba(16,24,40,.08)] backdrop-blur-xl"
            : "py-1"
        }`}
      >
        <a href="#home" className="rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#079455]">
          <HikmaLogo />
        </a>

        <nav className="hidden items-center gap-6 lg:flex" aria-label="Main navigation">
          {links.map(([href, text]) => (
            <a
              key={href}
              href={href}
              className="text-sm font-semibold text-[#475467] transition hover:text-[#079455]"
            >
              {text}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <LanguageSwitcher locale={locale} label={copy.language} />
          <a href="#contact" className="btn-primary text-sm">
            {copy.start}
          </a>
        </div>

        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          className="inline-flex h-11 w-11 items-center justify-center rounded-xl border border-[#079455]/15 bg-white text-[#101828] shadow-sm lg:hidden"
          aria-label={open ? copy.closeMenu : copy.openMenu}
          aria-expanded={open}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {open && (
        <div className="mx-4 mt-2 rounded-3xl border border-[#079455]/15 bg-white/95 p-4 shadow-[0_24px_60px_rgba(16,24,40,.12)] backdrop-blur-xl lg:hidden">
          <nav className="grid gap-1" aria-label="Mobile navigation">
            {links.map(([href, text]) => (
              <a
                key={href}
                href={href}
                onClick={() => setOpen(false)}
                className="rounded-xl px-4 py-3 text-base font-semibold text-[#344054] hover:bg-[#F4FBF7] hover:text-[#079455]"
              >
                {text}
              </a>
            ))}
          </nav>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#EAECF0] pt-4">
            <LanguageSwitcher locale={locale} label={copy.language} />
            <a href="#contact" onClick={() => setOpen(false)} className="btn-primary flex-1 text-center text-sm">
              {copy.start}
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
