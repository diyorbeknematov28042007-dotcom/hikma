import { Instagram, Send } from "lucide-react";
import { siteConfig } from "@/lib/site-config";
import { HikmaLogo } from "./hikma-logo";

type FooterCopy = {
  text: string;
  rights: string;
};

type NavCopy = {
  about: string;
  services: string;
  projects: string;
  contact: string;
};

export function Footer({ copy, nav }: { copy: FooterCopy; nav: NavCopy }) {
  const links = [
    ["#about", nav.about],
    ["#services", nav.services],
    ["#projects", nav.projects],
    ["#contact", nav.contact],
  ] as const;

  return (
    <footer className="border-t border-[#079455]/10 bg-[#F9FCFA]">
      <div className="section-shell py-10 sm:py-12">
        <div className="grid gap-8 md:grid-cols-[1fr_auto] md:items-start">
          <div>
            <HikmaLogo />
            <p className="mt-4 max-w-sm text-sm leading-6 text-[#667085]">{copy.text}</p>
          </div>
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
            <nav className="flex flex-wrap gap-x-5 gap-y-3">
              {links.map(([href, label]) => (
                <a key={href} href={href} className="text-sm font-bold text-[#475467] transition hover:text-[#079455]">
                  {label}
                </a>
              ))}
            </nav>
            <div className="flex gap-2">
              {siteConfig.instagramUrl && (
                <a href={siteConfig.instagramUrl} target="_blank" rel="noreferrer" aria-label="Instagram" className="social-button">
                  <Instagram size={18} />
                </a>
              )}
              {siteConfig.telegramUrl && (
                <a href={siteConfig.telegramUrl} target="_blank" rel="noreferrer" aria-label="Telegram" className="social-button">
                  <Send size={18} />
                </a>
              )}
            </div>
          </div>
        </div>
        <div className="mt-8 border-t border-[#079455]/10 pt-6 text-sm text-[#98A2B3]">{copy.rights}</div>
      </div>
    </footer>
  );
}
