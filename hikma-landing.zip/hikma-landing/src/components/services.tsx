import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";
import { ServiceCard } from "./service-card";

type ServicesCopy = {
  label: string;
  title: string;
  details: string;
  items: readonly {
    id: string;
    title: string;
    description: string;
    features: readonly string[];
  }[];
};

export function Services({ copy }: { copy: ServicesCopy }) {
  return (
    <section id="services" className="section-space bg-[#F9FCFA]">
      <div className="section-shell">
        <Reveal>
          <SectionHeader label={copy.label} title={copy.title} />
        </Reveal>
        <div className="mt-10 grid gap-5 xl:grid-cols-2">
          {copy.items.map((service, index) => (
            <Reveal key={service.id} delay={(index % 2) * 80}>
              <ServiceCard service={service} details={copy.details} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
