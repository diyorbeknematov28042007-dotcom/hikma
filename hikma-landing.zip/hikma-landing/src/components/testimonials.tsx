import { ImageIcon, MessageSquareQuote } from "lucide-react";
import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";

type TestimonialsCopy = {
  label: string;
  title: string;
  placeholder: string;
  hint: string;
};

export function Testimonials({ copy }: { copy: TestimonialsCopy }) {
  return (
    <section id="testimonials" className="section-space bg-[#F9FCFA]">
      <div className="section-shell">
        <Reveal>
          <SectionHeader label={copy.label} title={copy.title} />
        </Reveal>

        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {[0, 1, 2].map((item) => (
            <Reveal key={item} delay={item * 70}>
              <article className="h-full rounded-[2rem] border border-[#079455]/10 bg-white p-6 shadow-[0_18px_60px_rgba(16,24,40,.05)]">
                <div className="flex items-center justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#E8F7F0] text-[#079455]">
                    <MessageSquareQuote size={21} />
                  </span>
                  <span className="text-5xl font-black leading-none text-[#079455]/10">“</span>
                </div>
                <p className="mt-8 text-lg font-bold leading-7 text-[#344054]">{copy.placeholder}</p>
                <div className="mt-8 flex items-center gap-3 rounded-2xl border border-dashed border-[#079455]/20 bg-[#F4FBF7] p-4">
                  <ImageIcon size={18} className="shrink-0 text-[#079455]" />
                  <p className="text-xs font-semibold leading-5 text-[#667085]">{copy.hint}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
