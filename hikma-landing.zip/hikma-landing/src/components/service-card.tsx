import {
  Bot,
  Check,
  ChevronRight,
  Globe2,
  Instagram,
  Send,
} from "lucide-react";

type Service = {
  id: string;
  title: string;
  description: string;
  features: readonly string[];
};

function ServiceVisual({ id }: { id: string }) {
  if (id === "landing") {
    return (
      <div className="service-visual">
        <div className="mock-laptop">
          <div className="mock-browser">
            <div className="mock-browser-top"><i /><i /><i /></div>
            <div className="grid gap-2 p-3">
              <span className="h-3 w-1/2 rounded-full bg-[#079455]/25" />
              <span className="h-8 rounded-lg bg-[#079455]" />
              <div className="grid grid-cols-3 gap-2">
                <span className="h-12 rounded-lg bg-white" />
                <span className="h-12 rounded-lg bg-[#E8F7F0]" />
                <span className="h-12 rounded-lg bg-white" />
              </div>
            </div>
          </div>
        </div>
        <div className="mock-phone">
          <div className="mx-auto mt-2 h-1.5 w-8 rounded-full bg-[#101828]/20" />
          <div className="mx-2 mt-3 h-10 rounded-lg bg-[#079455]" />
          <div className="mx-2 mt-2 h-4 rounded-md bg-[#E8F7F0]" />
          <div className="mx-2 mt-2 h-8 rounded-md bg-white" />
        </div>
      </div>
    );
  }

  if (id === "bot") {
    return (
      <div className="service-visual flex items-center justify-center">
        <div className="relative w-full max-w-[270px] rounded-[1.5rem] border border-[#079455]/12 bg-white p-4 shadow-lg">
          <div className="mb-4 flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-[#079455] text-white"><Bot size={20} /></span>
            <div>
              <div className="h-2.5 w-20 rounded-full bg-[#101828]/80" />
              <div className="mt-1.5 h-2 w-12 rounded-full bg-[#079455]/25" />
            </div>
          </div>
          <div className="ml-auto w-3/4 rounded-2xl rounded-br-md bg-[#E8F7F0] p-3">
            <div className="h-2 rounded-full bg-[#079455]/25" />
            <div className="mt-2 h-2 w-2/3 rounded-full bg-[#079455]/20" />
          </div>
          <div className="mt-3 w-4/5 rounded-2xl rounded-bl-md bg-[#F2F4F7] p-3">
            <div className="h-2 rounded-full bg-[#667085]/20" />
            <div className="mt-2 h-2 w-1/2 rounded-full bg-[#667085]/15" />
          </div>
        </div>
      </div>
    );
  }

  if (id === "instagram") {
    return (
      <div className="service-visual flex items-center justify-center">
        <div className="w-full max-w-[280px] rounded-[1.5rem] border border-[#079455]/12 bg-white p-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#E8F7F0] text-[#079455]"><Instagram size={19} /></span>
            <span className="rounded-full bg-[#F4FBF7] px-2 py-1 text-[10px] font-bold text-[#079455]">ADS</span>
          </div>
          <div className="mt-4 h-28 rounded-2xl bg-[linear-gradient(135deg,#079455,#E8F7F0)] p-3">
            <div className="h-3 w-2/3 rounded-full bg-white/90" />
            <div className="mt-2 h-2 w-1/2 rounded-full bg-white/60" />
          </div>
          <div className="mt-4 flex h-16 items-end gap-2">
            {[36, 55, 42, 72, 62, 88].map((height, i) => (
              <span key={i} className="flex-1 rounded-t-md bg-[#079455]/20" style={{ height: `${height}%` }}>
                <span className="block h-full rounded-t-md bg-[#079455]" style={{ opacity: .45 + i * .08 }} />
              </span>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="service-visual flex items-center justify-center">
      <div className="relative w-full max-w-[280px] rounded-[1.5rem] border border-[#079455]/12 bg-white p-4 shadow-lg">
        <div className="flex items-center gap-3 border-b border-[#EAECF0] pb-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#079455] text-white"><Send size={19} /></span>
          <div className="min-w-0 flex-1">
            <div className="h-2.5 w-20 rounded-full bg-[#101828]/80" />
            <div className="mt-1.5 h-2 w-28 rounded-full bg-[#98A2B3]/25" />
          </div>
        </div>
        <div className="mt-4 rounded-2xl bg-[#F4FBF7] p-4">
          <div className="h-2.5 w-2/3 rounded-full bg-[#079455]/30" />
          <div className="mt-2 h-2 rounded-full bg-[#079455]/18" />
          <div className="mt-2 h-2 w-4/5 rounded-full bg-[#079455]/18" />
          <div className="mt-4 flex justify-between">
            <span className="text-[10px] font-bold text-[#079455]">Sponsored</span>
            <span className="h-2 w-10 rounded-full bg-[#079455]/30" />
          </div>
        </div>
      </div>
    </div>
  );
}

export function ServiceCard({ service, details }: { service: Service; details: string }) {
  const Icon = service.id === "landing" ? Globe2 : service.id === "bot" ? Bot : service.id === "instagram" ? Instagram : Send;

  return (
    <article className="service-card group">
      <div className="service-card-inner">
        <div>
          <div className="mb-5 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[#E8F7F0] text-[#079455] transition duration-300 group-hover:scale-105 group-hover:bg-[#079455] group-hover:text-white">
            <Icon size={23} />
          </div>
          <h3 className="text-2xl font-black tracking-[-0.03em] text-[#101828]">{service.title}</h3>
          <p className="mt-3 leading-7 text-[#667085]">{service.description}</p>
          <ul className="mt-5 grid gap-2.5">
            {service.features.map((feature) => (
              <li key={feature} className="flex items-center gap-2.5 text-sm font-semibold text-[#475467]">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#E8F7F0] text-[#079455]"><Check size={13} strokeWidth={3} /></span>
                {feature}
              </li>
            ))}
          </ul>
          <a href="#contact" className="mt-6 inline-flex items-center gap-1 text-sm font-extrabold text-[#079455]">
            {details}
            <ChevronRight size={16} className="transition group-hover:translate-x-1" />
          </a>
        </div>
        <ServiceVisual id={service.id} />
      </div>
    </article>
  );
}
