import { Instagram, Mail, Send } from "lucide-react";
import { siteConfig } from "@/lib/site-config";
import { ContactForm } from "./contact-form";
import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";

type ContactCopy = {
  title: string;
  intro: string;
  telegram: string;
  instagram: string;
  email: string;
  form: {
    name: string;
    contact: string;
    service: string;
    message: string;
    submit: string;
    sending: string;
    choose: string;
    services: readonly string[];
    success: string;
    error: string;
  };
};

export function Contact({ copy }: { copy: ContactCopy }) {
  const contacts = [
    {
      label: copy.telegram,
      value: siteConfig.telegramUrl ? siteConfig.telegramUrl.replace(/^https?:\/\//, "") : "Telegram",
      href: siteConfig.telegramUrl || "#contact-form",
      Icon: Send,
    },
    {
      label: copy.instagram,
      value: siteConfig.instagramUrl ? siteConfig.instagramUrl.replace(/^https?:\/\//, "") : "Instagram",
      href: siteConfig.instagramUrl || "#contact-form",
      Icon: Instagram,
    },
    {
      label: copy.email,
      value: siteConfig.email || "Email",
      href: siteConfig.email ? `mailto:${siteConfig.email}` : "#contact-form",
      Icon: Mail,
    },
  ];

  return (
    <section id="contact" className="section-space">
      <div className="section-shell grid gap-10 lg:grid-cols-[.75fr_1.25fr] lg:items-start">
        <Reveal>
          <div className="lg:sticky lg:top-28">
            <SectionHeader title={copy.title} />
            <p className="mt-5 max-w-lg leading-7 text-[#667085]">{copy.intro}</p>
            <div className="mt-8 grid gap-3">
              {contacts.map(({ label, value, href, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target={href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  className="group flex items-center gap-4 rounded-2xl border border-[#079455]/10 bg-[#F4FBF7] p-4 transition hover:border-[#079455]/25 hover:bg-[#E8F7F0]"
                >
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white text-[#079455] shadow-sm">
                    <Icon size={20} />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-xs font-bold uppercase tracking-[0.12em] text-[#98A2B3]">{label}</span>
                    <span className="block truncate font-extrabold text-[#344054]">{value}</span>
                  </span>
                </a>
              ))}
            </div>
          </div>
        </Reveal>

        <Reveal delay={90} className="scroll-mt-28" >
          <div id="contact-form">
            <ContactForm copy={copy.form} />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
