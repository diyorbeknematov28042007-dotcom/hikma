import { ArrowUpRight, Bot, Scale, Sparkles } from "lucide-react";
import { Reveal } from "./reveal";
import { SectionHeader } from "./section-header";

type ProjectsCopy = {
  label: string;
  titleA: string;
  titleB: string;
  category: string;
  project: string;
  status: string;
  description: string;
  cta: string;
  coming: string;
};

export function Projects({ copy }: { copy: ProjectsCopy }) {
  return (
    <section id="projects" className="section-space">
      <div className="section-shell">
        <Reveal>
          <SectionHeader
            label={copy.label}
            title={
              <>
                {copy.titleA}
                <br />
                <span className="text-[#079455]">{copy.titleB}</span>
              </>
            }
          />
        </Reveal>

        <div className="mt-10 grid gap-5 lg:grid-cols-[1.35fr_.65fr]">
          <Reveal>
            <article className="relative overflow-hidden rounded-[2.25rem] bg-[#071D14] p-6 text-white sm:p-9">
              <div className="project-pattern absolute inset-0 opacity-60" />
              <div className="relative z-10 grid gap-10 lg:grid-cols-[.85fr_1.15fr] lg:items-center">
                <div>
                  <div className="flex flex-wrap gap-2">
                    <span className="rounded-full border border-white/15 bg-white/10 px-3 py-1.5 text-xs font-bold text-[#D8F5E7]">{copy.category}</span>
                    <span className="rounded-full bg-[#079455] px-3 py-1.5 text-xs font-bold text-white">{copy.status}</span>
                  </div>
                  <h3 className="mt-6 text-4xl font-black tracking-[-0.05em] sm:text-5xl">{copy.project}</h3>
                  <p className="mt-4 max-w-lg leading-7 text-white/70">{copy.description}</p>
                  <a href="#contact" className="mt-7 inline-flex items-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-extrabold text-[#071D14] transition hover:bg-[#E8F7F0]">
                    {copy.cta}
                    <ArrowUpRight size={17} />
                  </a>
                </div>

                <div className="relative mx-auto w-full max-w-lg">
                  <div className="rounded-[2rem] border border-white/15 bg-white/10 p-4 shadow-2xl backdrop-blur">
                    <div className="rounded-[1.5rem] bg-white p-4 text-[#101828]">
                      <div className="flex items-center justify-between border-b border-[#EAECF0] pb-3">
                        <div className="flex items-center gap-3">
                          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#079455] text-white"><Scale size={20} /></span>
                          <div>
                            <div className="text-sm font-black">YURISTIM</div>
                            <div className="text-[10px] font-semibold text-[#98A2B3]">LegalTech ecosystem</div>
                          </div>
                        </div>
                        <Sparkles size={18} className="text-[#079455]" />
                      </div>
                      <div className="mt-4 grid grid-cols-2 gap-3">
                        <div className="rounded-2xl bg-[#F4FBF7] p-4">
                          <Bot className="text-[#079455]" size={21} />
                          <div className="mt-5 h-2 w-3/4 rounded-full bg-[#079455]/25" />
                          <div className="mt-2 h-2 w-1/2 rounded-full bg-[#079455]/15" />
                        </div>
                        <div className="rounded-2xl border border-[#079455]/10 p-4">
                          <Scale className="text-[#079455]" size={21} />
                          <div className="mt-5 h-2 w-2/3 rounded-full bg-[#101828]/20" />
                          <div className="mt-2 h-2 w-4/5 rounded-full bg-[#101828]/10" />
                        </div>
                      </div>
                      <div className="mt-3 rounded-2xl bg-[#101828] p-4">
                        <div className="flex h-16 items-end gap-2">
                          {[48, 70, 55, 84, 74, 94].map((h, i) => (
                            <span key={i} className="flex-1 rounded-t-md bg-[#079455]" style={{ height: `${h}%`, opacity: .45 + i * .09 }} />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </article>
          </Reveal>

          <Reveal delay={100}>
            <article className="flex min-h-[380px] flex-col justify-between rounded-[2.25rem] border border-dashed border-[#079455]/25 bg-[#F4FBF7] p-7">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-[#079455]/15 bg-white text-[#079455] shadow-sm">
                <span className="text-2xl font-black">+</span>
              </div>
              <div>
                <p className="text-sm font-bold uppercase tracking-[0.14em] text-[#079455]">HIKMA LAB</p>
                <h3 className="mt-3 text-2xl font-black tracking-[-0.03em] text-[#101828]">{copy.coming}</h3>
              </div>
            </article>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
