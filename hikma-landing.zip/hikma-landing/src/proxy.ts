import { NextRequest, NextResponse } from "next/server";

const locales = ["uz", "ru", "en"];

export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname === "/") {
    return NextResponse.redirect(new URL("/uz", request.url));
  }

  const firstSegment = pathname.split("/")[1];
  if (
    firstSegment &&
    !locales.includes(firstSegment) &&
    !pathname.startsWith("/api") &&
    !pathname.startsWith("/_next") &&
    !pathname.includes(".")
  ) {
    return NextResponse.redirect(new URL("/uz", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
